#!/usr/bin/env python3
"""
Geospatial Data Analysis for Business Expansion
================================================
Finds regions with HIGH DEMAND but LOW PRESENCE and recommends new store sites.

Pipeline
--------
1. Load sales transactions (lat, lon, amount) and existing store locations
   (or generate a realistic synthetic dataset for Kerala, India).
2. Aggregate sales into a regular lat/lon grid and smooth with a Gaussian kernel
   -> demand surface.
3. Compute store presence per cell (distance to nearest store, stores in radius)
   -> coverage surface.
4. Opportunity score = normalised demand x (1 - coverage).
5. Cluster the top-scoring cells (weighted KMeans) -> ranked candidate sites.
6. Export CSVs, static PNG maps and an interactive Leaflet HTML map.

Usage
-----
    python geospatial_expansion_analysis.py                       # synthetic demo
    python geospatial_expansion_analysis.py --sales my_sales.csv --stores my_stores.csv

Input CSV formats
-----------------
    sales.csv  : lat, lon, amount            (one row per transaction / customer)
    stores.csv : store_id, name, lat, lon    (existing locations)
"""
import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter
from sklearn.cluster import KMeans

EARTH_R_KM = 6371.0088

# --------------------------------------------------------------------------- #
# 1. Data loading / synthetic data
# --------------------------------------------------------------------------- #
# name, lat, lon, demand weight, spread (deg)
CITIES = [
    ("Thiruvananthapuram", 8.5241, 76.9366, 1.00, 0.12),
    ("Kollam",             8.8932, 76.6141, 0.80, 0.09),
    ("Pathanamthitta",     9.2648, 76.7870, 0.35, 0.07),
    ("Alappuzha",          9.4981, 76.3388, 0.55, 0.07),
    ("Kottayam",           9.5916, 76.5222, 0.60, 0.08),
    ("Kochi",              9.9312, 76.2673, 1.20, 0.12),
    ("Thrissur",          10.5276, 76.2144, 0.75, 0.09),
    ("Palakkad",          10.7867, 76.6548, 0.50, 0.10),
    ("Malappuram",        11.0510, 76.0711, 0.95, 0.11),
    ("Kozhikode",         11.2588, 75.7804, 1.10, 0.10),
    ("Kannur",            11.8745, 75.3704, 0.60, 0.09),
    ("Kasaragod",         12.4996, 74.9869, 0.30, 0.07),
]
# Existing stores are deliberately concentrated in the south & Kochi, so the
# north (Kozhikode / Malappuram / Kannur) shows up as an under-served market.
STORE_CITIES = {"Thiruvananthapuram": 3, "Kollam": 2, "Alappuzha": 1,
                "Kottayam": 1, "Kochi": 4, "Thrissur": 2, "Palakkad": 1}


def generate_synthetic(seed=42, n_sales=30000):
    rng = np.random.default_rng(seed)
    w = np.array([c[3] for c in CITIES])
    w = w / w.sum()
    idx = rng.choice(len(CITIES), size=n_sales, p=w)
    lats, lons = [], []
    for i in idx:
        _, la, lo, _, sp = CITIES[i]
        lats.append(rng.normal(la, sp))
        lons.append(rng.normal(lo, sp * 1.1))
    sales = pd.DataFrame({
        "lat": lats, "lon": lons,
        "amount": rng.lognormal(mean=6.0, sigma=0.6, size=n_sales).round(2),  # INR
        "nearest_city": [CITIES[i][0] for i in idx],
    })

    rows, sid = [], 1
    for name, la, lo, _, sp in CITIES:
        for _ in range(STORE_CITIES.get(name, 0)):
            rows.append({"store_id": f"S{sid:03d}", "name": f"{name} Store {sid}",
                         "lat": rng.normal(la, sp * 0.5), "lon": rng.normal(lo, sp * 0.5)})
            sid += 1
    return sales, pd.DataFrame(rows)


def load_data(args):
    if args.sales and args.stores:
        sales = pd.read_csv(args.sales)
        stores = pd.read_csv(args.stores)
        for df, cols in ((sales, {"lat", "lon", "amount"}), (stores, {"lat", "lon"})):
            missing = cols - set(df.columns)
            if missing:
                raise ValueError(f"Missing columns: {missing}")
        if "store_id" not in stores:
            stores["store_id"] = [f"S{i+1:03d}" for i in range(len(stores))]
        if "name" not in stores:
            stores["name"] = stores["store_id"]
        return sales.dropna(subset=["lat", "lon", "amount"]), stores
    print("No input files given -> generating synthetic Kerala dataset.")
    return generate_synthetic(args.seed)


# --------------------------------------------------------------------------- #
# 2-4. Grid, demand, presence, opportunity
# --------------------------------------------------------------------------- #
def haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dphi = p2 - p1
    dl = np.radians(lon2) - np.radians(lon1)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * EARTH_R_KM * np.arcsin(np.sqrt(a))


def build_grid(sales, stores, cell_deg, smooth_sigma, catchment_km):
    pad = 0.1
    lat_min, lat_max = sales.lat.min() - pad, sales.lat.max() + pad
    lon_min, lon_max = sales.lon.min() - pad, sales.lon.max() + pad
    lat_edges = np.arange(lat_min, lat_max + cell_deg, cell_deg)
    lon_edges = np.arange(lon_min, lon_max + cell_deg, cell_deg)

    # Demand: total sales per cell, smoothed to represent a catchment area
    rev, _, _ = np.histogram2d(sales.lat, sales.lon, bins=[lat_edges, lon_edges],
                               weights=sales.amount)
    cnt, _, _ = np.histogram2d(sales.lat, sales.lon, bins=[lat_edges, lon_edges])
    demand = gaussian_filter(rev, sigma=smooth_sigma)

    lat_c = (lat_edges[:-1] + lat_edges[1:]) / 2
    lon_c = (lon_edges[:-1] + lon_edges[1:]) / 2
    LON, LAT = np.meshgrid(lon_c, lat_c)

    # Presence: distance to nearest store + store count in catchment
    d = haversine_km(LAT[..., None], LON[..., None],
                     stores.lat.values[None, None, :], stores.lon.values[None, None, :])
    nearest_km = d.min(axis=2)
    stores_in_radius = (d <= catchment_km).sum(axis=2)
    coverage = np.exp(-nearest_km / catchment_km)        # 1 at a store, ->0 far away
    coverage = np.clip(coverage + 0.1 * np.minimum(stores_in_radius, 3), 0, 1)

    demand_n = demand / demand.max()
    opportunity = demand_n * (1 - coverage)

    grid = pd.DataFrame({
        "lat": LAT.ravel(), "lon": LON.ravel(),
        "revenue": rev.ravel(), "transactions": cnt.ravel(),
        "demand_smooth": demand.ravel(), "demand_norm": demand_n.ravel(),
        "nearest_store_km": nearest_km.ravel(),
        "stores_in_radius": stores_in_radius.ravel(),
        "coverage": coverage.ravel(), "opportunity": opportunity.ravel(),
    })
    return grid, (lat_edges, lon_edges)


# --------------------------------------------------------------------------- #
# 5. Candidate sites
# --------------------------------------------------------------------------- #
def find_candidate_sites(grid, n_sites, top_pct, seed):
    thr = grid.opportunity.quantile(top_pct)
    hot = grid[(grid.opportunity >= thr) & (grid.opportunity > 0)].copy()
    k = min(n_sites, len(hot))
    km = KMeans(n_clusters=k, n_init=10, random_state=seed)
    hot["cluster"] = km.fit_predict(hot[["lat", "lon"]], sample_weight=hot.opportunity)

    rows = []
    for c, g in hot.groupby("cluster"):
        w = g.opportunity
        rows.append({
            "lat": np.average(g.lat, weights=w), "lon": np.average(g.lon, weights=w),
            "opportunity_score": g.opportunity.sum(),
            "catchment_revenue": g.demand_smooth.sum(),
            "avg_dist_to_store_km": g.nearest_store_km.mean(),
            "hot_cells": len(g),
        })
    cand = pd.DataFrame(rows).sort_values("opportunity_score", ascending=False)
    cand["rank"] = range(1, len(cand) + 1)
    cand["opportunity_score"] = (cand.opportunity_score / cand.opportunity_score.max() * 100).round(1)
    return cand[["rank", "lat", "lon", "opportunity_score", "catchment_revenue",
                 "avg_dist_to_store_km", "hot_cells"]].round(4), hot


def label_with_city(cand):
    """Attach nearest reference city name (only for the built-in demo cities)."""
    names = []
    for _, r in cand.iterrows():
        d = [haversine_km(r.lat, r.lon, c[1], c[2]) for c in CITIES]
        i = int(np.argmin(d))
        names.append(f"{CITIES[i][0]} (~{d[i]:.0f} km)" if d[i] < 60 else "")
    cand["near"] = names
    return cand


# --------------------------------------------------------------------------- #
# 6. Outputs: static maps + interactive Leaflet map
# --------------------------------------------------------------------------- #
def static_maps(sales, stores, grid, cand, edges, out):
    lat_e, lon_e = edges
    shape = (len(lat_e) - 1, len(lon_e) - 1)
    extent = [lon_e[0], lon_e[-1], lat_e[0], lat_e[-1]]
    fig, axes = plt.subplots(1, 3, figsize=(20, 9))
    panels = [("Demand (smoothed sales)", "demand_smooth", "YlOrRd"),
              ("Store coverage", "coverage", "Blues"),
              ("Opportunity = demand x (1 - coverage)", "opportunity", "magma_r")]
    for ax, (title, col, cmap) in zip(axes, panels):
        im = ax.imshow(grid[col].values.reshape(shape), origin="lower", extent=extent,
                       cmap=cmap, aspect="auto")
        ax.scatter(stores.lon, stores.lat, c="cyan" if col == "opportunity" else "black",
                   marker="s", s=35, edgecolor="white", label="Existing stores", zorder=3)
        if col == "opportunity":
            ax.scatter(cand.lon, cand.lat, c="lime", marker="*", s=380, edgecolor="black",
                       label="Recommended sites", zorder=4)
            for _, r in cand.iterrows():
                ax.annotate(int(r["rank"]), (r.lon, r.lat), ha="center", va="center",
                            fontsize=8, fontweight="bold", zorder=5)
        ax.set_title(title, fontsize=13, fontweight="bold")
        ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
        ax.legend(loc="lower left", fontsize=8)
        fig.colorbar(im, ax=ax, shrink=0.7)
    fig.suptitle("Geospatial Expansion Analysis", fontsize=16, fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "expansion_maps.png"), dpi=150)
    plt.close(fig)

    # Sales density hexbin
    fig, ax = plt.subplots(figsize=(8, 10))
    hb = ax.hexbin(sales.lon, sales.lat, C=sales.amount, reduce_C_function=np.sum,
                   gridsize=60, cmap="YlOrRd", mincnt=1)
    ax.scatter(stores.lon, stores.lat, c="black", marker="s", s=40, edgecolor="white",
               label="Existing stores")
    ax.set_title("Sales revenue density", fontweight="bold")
    ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude"); ax.legend()
    fig.colorbar(hb, label="Revenue")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "sales_density.png"), dpi=150)
    plt.close(fig)


LEAFLET_TEMPLATE = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>Expansion Opportunity Map</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js"></script>
<style>
 html,body,#map{height:100%;margin:0;font-family:system-ui,sans-serif}
 .legend{background:#fff;padding:8px 10px;border-radius:6px;box-shadow:0 1px 5px rgba(0,0,0,.4);font-size:12px;line-height:1.5}
 .dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px}
</style></head><body><div id="map"></div>
<script>
const stores=__STORES__, cands=__CANDS__, cells=__CELLS__, heat=__HEAT__;
const map=L.map('map').setView([__CLAT__,__CLON__],8);
const osm=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
const sat=L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',{attribution:'&copy; CARTO'});

const heatLayer=L.heatLayer(heat,{radius:18,blur:22,maxZoom:11}).addTo(map);

const oppLayer=L.layerGroup().addTo(map);
cells.forEach(c=>{
  const a=0.15+0.6*c.s;
  L.rectangle([[c.lat-__H__,c.lon-__H__],[c.lat+__H__,c.lon+__H__]],
    {color:'#7b1fa2',weight:0,fillColor:'#7b1fa2',fillOpacity:a})
   .bindTooltip('Opportunity '+(c.s*100).toFixed(0)+'/100<br>Nearest store: '+c.d.toFixed(1)+' km')
   .addTo(oppLayer);
});

const storeLayer=L.layerGroup().addTo(map);
stores.forEach(s=>L.circleMarker([s.lat,s.lon],{radius:6,color:'#fff',weight:1.5,fillColor:'#1565c0',fillOpacity:1})
  .bindPopup('<b>'+s.name+'</b><br>'+s.store_id).addTo(storeLayer));

const candLayer=L.layerGroup().addTo(map);
cands.forEach(c=>{
  const icon=L.divIcon({className:'',html:'<div style="background:#2e7d32;color:#fff;border:2px solid #fff;border-radius:50%;width:28px;height:28px;line-height:24px;text-align:center;font-weight:700;box-shadow:0 0 4px #000">'+c.rank+'</div>',iconSize:[28,28],iconAnchor:[14,14]});
  L.marker([c.lat,c.lon],{icon}).bindPopup(
    '<b>Recommended site #'+c.rank+'</b>'+(c.near?'<br>'+c.near:'')+
    '<br>Opportunity score: '+c.opportunity_score+
    '<br>Catchment revenue: '+Math.round(c.catchment_revenue).toLocaleString()+
    '<br>Avg dist. to store: '+c.avg_dist_to_store_km.toFixed(1)+' km').addTo(candLayer);
});

L.control.layers({'OpenStreetMap':osm,'Dark':sat},
 {'Sales heatmap':heatLayer,'High-opportunity cells':oppLayer,'Existing stores':storeLayer,'Recommended sites':candLayer},
 {collapsed:false}).addTo(map);

const lg=L.control({position:'bottomright'});
lg.onAdd=()=>{const d=L.DomUtil.create('div','legend');
 d.innerHTML='<b>Legend</b><br><span class="dot" style="background:#1565c0"></span>Existing store<br>'+
 '<span class="dot" style="background:#2e7d32"></span>Recommended site (ranked)<br>'+
 '<span class="dot" style="background:#7b1fa2"></span>High demand / low presence';return d;};
lg.addTo(map);
</script></body></html>"""


def interactive_map(sales, stores, grid, cand, cell_deg, out):
    hot = grid[grid.opportunity >= grid.opportunity.quantile(0.9)]
    smax = hot.opportunity.max()
    cells = [{"lat": round(r.lat, 4), "lon": round(r.lon, 4),
              "s": round(r.opportunity / smax, 3), "d": round(r.nearest_store_km, 2)}
             for r in hot.itertuples()]
    samp = sales.sample(min(len(sales), 8000), random_state=1)
    wmax = samp.amount.quantile(0.95)
    heat = [[round(a, 4), round(b, 4), round(min(w / wmax, 1), 3)]
            for a, b, w in zip(samp.lat, samp.lon, samp.amount)]
    html = (LEAFLET_TEMPLATE
            .replace("__STORES__", json.dumps(stores[["store_id", "name", "lat", "lon"]].round(5).to_dict("records")))
            .replace("__CANDS__", json.dumps(cand.fillna("").to_dict("records")))
            .replace("__CELLS__", json.dumps(cells))
            .replace("__HEAT__", json.dumps(heat))
            .replace("__CLAT__", str(round(sales.lat.mean(), 3)))
            .replace("__CLON__", str(round(sales.lon.mean(), 3)))
            .replace("__H__", str(cell_deg / 2)))
    with open(os.path.join(out, "expansion_map.html"), "w", encoding="utf-8") as f:
        f.write(html)


# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sales"); ap.add_argument("--stores")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--cell-deg", type=float, default=0.05, help="grid cell size in degrees (~5.5 km)")
    ap.add_argument("--smooth", type=float, default=2.0, help="Gaussian smoothing sigma (cells)")
    ap.add_argument("--catchment-km", type=float, default=15.0, help="store catchment radius")
    ap.add_argument("--n-sites", type=int, default=8)
    ap.add_argument("--top-pct", type=float, default=0.93, help="quantile of cells treated as hot")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    sales, stores = load_data(args)
    print(f"Loaded {len(sales):,} sales rows and {len(stores)} stores.")

    grid, edges = build_grid(sales, stores, args.cell_deg, args.smooth, args.catchment_km)
    cand, hot = find_candidate_sites(grid, args.n_sites, args.top_pct, args.seed)
    cand = label_with_city(cand) if args.sales is None else cand.assign(near="")

    grid.to_csv(os.path.join(args.out, "grid_scores.csv"), index=False)
    cand.to_csv(os.path.join(args.out, "recommended_sites.csv"), index=False)
    if args.sales is None:
        sales.to_csv(os.path.join(args.out, "sample_sales.csv"), index=False)
        stores.to_csv(os.path.join(args.out, "sample_stores.csv"), index=False)

    static_maps(sales, stores, grid, cand, edges, args.out)
    interactive_map(sales, stores, grid, cand, args.cell_deg, args.out)

    print("\nTop recommended expansion sites:")
    cols = ["rank", "near", "lat", "lon", "opportunity_score", "avg_dist_to_store_km"]
    print(cand[cols].to_string(index=False))
    print(f"\nOutputs written to ./{args.out}/  (open expansion_map.html in a browser)")


if __name__ == "__main__":
    main()
